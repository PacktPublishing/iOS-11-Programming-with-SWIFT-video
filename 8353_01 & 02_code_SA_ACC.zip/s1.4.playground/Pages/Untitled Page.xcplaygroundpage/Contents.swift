//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, world"
var str1 = "Mike"

print(str1)

for number in [1,2,3,4,5] {
    print(number)
}

//: [Next](@next)
