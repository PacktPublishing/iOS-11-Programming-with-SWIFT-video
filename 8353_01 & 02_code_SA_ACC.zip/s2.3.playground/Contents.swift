//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var str1: String = "Hello, playground"

var number = 42.0
print(number)

var intNumber = Int(number)
print(intNumber)

let dividend = 15
let divisor = 4
let quotient = Double(dividend) / Double(divisor)

print(quotient)

var stringFromNumber = String(quotient)
print(stringFromNumber)
var stringFromNumber1 = "The result is: \(quotient)."
print(stringFromNumber1)
